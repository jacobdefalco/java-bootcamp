package assignments;

public class MyProfile {
    public static void main(String[] args) {
        System.out.println("""
                Name: Jacob DeFalco
                ***
                Campus: Pittsburgh, PA
                ***
                Career Goal: Cyber Security Technician
                ***
                Age: 26
                ***
                Brief Intro: I'm just a kid (Simple Plan reference) just trying to make it in this crazy world
                """);
    }
}
